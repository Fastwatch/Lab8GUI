

public interface Directory {

	
	public void print();
	public void add(String s);
	public void clr();
	
	
}
